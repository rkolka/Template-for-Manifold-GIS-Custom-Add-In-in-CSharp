$safeprojectname$
Manifold Add-in created by $username$ in $time$.

Copyright $username$, $userdomain$ $year$.
